#ifndef ESP32CONTROLCONFIG_H
#define ESP32CONTROLCONFIG_H
#include <Arduino.h>

uint8_t board_version;

#endif