# ESP32_Control v 1.2.8.1
- Syntex hilight for readInputRegistorsI
# ESP32_Control v 1.2.7.1
- Bug fixed for Modbus function readHoldingRegistorI
# ESP32_Control v 1.2.7
- GPIO Lib updated
# ESP32_Control v 1.2.6
- Tutor012 added
- web monitor bug fixed
# ESP32_Control v 1.2.5
ESP32 Control library for All TF ESP32 Control module and Mini PLC RLX-32U
Last updated 22/5/2022
- Mini PLC RLX-32U added
# ESP32_Control v 1.2.4
ESP32 Control library for All TF ESP32 Control module
Last updated 4/5/2022
- Sample tutor07 Modbus TCP Slave added
- Improved keywords
# ESP32_Control v 1.2.3
ESP32 Control library for All TF ESP32 Control module
Last updated 28/4/2022
- v1.0RX added
- RX-32U version added
- update IO Function

# ESP32_Control v 1.2.2
ESP32 Control library for All TF ESP32 Control module
Last updated 6/4/2022
- readinput
- parameter sugestion when use vscode
- example adjustment
- Modbus rs485 - webmonitor
- Bug fixed - can not use missing library